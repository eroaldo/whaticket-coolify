# Frontend Placeholder
Este diretório deve conter os arquivos do frontend do Whaticket.